# -*- coding: utf-8 -*-
"""
Created on Thu Jan 14 13:44:00 2016
This file shows some simple (and buggy) python code to solve the Triangles assignment.   
The primary goal of this file is to demonstrate a simple python program and the use of the
unittest package.
Note that this code includes intentional errors for you to find.
@author: jrr
"""

import unittest  # this makes Python unittest module available


def classifyTriangle(a, b, c):
    """

    This function returns a string with the type of triangle from three integer values
    corresponding to the lengths of the three sides of the Triangle.

    return:
        If all three sides are equal, return 'Equilateral'
        If exactly one pair of sides are equal, return 'Isoceles'
        If no pair of  sides are equal, return 'Scalene'
        If not a valid triangle, then return 'NotATriangle'
        If the sum of any two sides equals the squate of the third side, then return 'Right'


      BEWARE: there may be a bug or two in this code

    """
    if not (isinstance(a, int) and isinstance(b, int) and isinstance(c, int)):
        return 'InvalidInput';
    # require that the input values be > 0 and <= 200
    if a > 200 or b > 200 or c > 200:
        return 'InvalidInput'

    if a <= 0 or b <= 0 or c <= 0:
        return 'InvalidInput'

    # verify that all 3 inputs are integers
    # Python's "isinstance(object,type) returns True if the object is of the specified type


    # This information was not in the requirements spec but
    # is important for correctness
    # the sum of any two sides must be strictly less than the third side
    # of the specified shape is not a triangle
    a, b, c = sorted([a,b,c])
    x, y, z = a + b, b + c, c + a
    p, q, r = a * a, b * b, c * c
    if not (x > c and y > a and z > b):
        return 'NotATriangle'

    # now we know that we have a valid triangle 
    if a == b and b == a:
        return 'Equilateral'
    elif r == p + q:
        return 'Right'
    elif (a != b) and (b != c) and (a != c):
        return 'Scalene'
    else:
        return 'Isoceles'


def runClassifyTriangle(a, b, c):
    """ invoke buggyTriangle with the specified arguments and print the result """
    print('classifyTriangle(', a, ',', b, ',', c, ')=', classifyTriangle(a, b, b), sep="")


# The remainder of this code implements the unit test functionality

# https://docs.python.org/3/library/unittest.html has a nice description of the framework

class TestTriangles(unittest.TestCase):
    # define multiple sets of tests as functions with names that begin
    # with 'test'.  Each function may include multiple tests
    def testToRun1(self):
        self.assertEqual(classifyTriangle(5, 3, 5), "Isoceles")

    def testToRun2(self):
        self.assertEqual(classifyTriangle(5, 5, 5), "Equilateral")

    def testToRun3(self):
        self.assertEqual(classifyTriangle(6, 4, 5), "Scalene")

    def testToRun4(self):
        self.assertEqual(classifyTriangle(4, 5, 3), "Right")

    def testToRun5(self):
        self.assertEqual(classifyTriangle("a", 3, 5), "InvalidInput")

    def testToRun6(self):
        self.assertEqual(classifyTriangle(0, 3, 5), "InvalidInput")

    def testToRun7(self):
        self.assertEqual(classifyTriangle(10, -7, 8), "InvalidInput")

    def testToRun8(self):
        self.assertEqual(classifyTriangle(7,8,9), "Scalene")

    def testToRun9(self):
        self.assertEqual(classifyTriangle(10, 10, 40), "NotATriangle")

    def testToRun10(self):
            self.assertEqual(classifyTriangle(200, 199, 180), "Scalene")


if __name__ == '__main__':
    # examples of running the  code
    runClassifyTriangle(1, 2, 3)
    runClassifyTriangle(1, 1, 1)
    runClassifyTriangle(3, 4, 5)

    print('Begin UnitTest')
    unittest.main(exit=False)  # this runs all of the tests - use this line if running from Spyder
    # unittest.main(exit=True) # this runs all of the tests - use this line if running from the command line
